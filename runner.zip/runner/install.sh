#!/usr/bin/env bash
#
# Signi local runner — one-command setup (macOS / Linux).
#
#   bash install.sh            set up and start (default)
#   bash install.sh status     is it running and reachable?
#   bash install.sh stop       stop it
#   bash install.sh uninstall  stop and remove the service
#
# After setup the runner stays on in the background and starts again after a
# reboot, so operators only ever press "Run now" on the website.
#
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY_VERSION="${CASEWISE_PY_VERSION:-3.11}"
# Neutral, unbranded names for everything left on the operator's machine.
LABEL="com.signi.agent"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
UNIT="$HOME/.config/systemd/user/signi-agent.service"
OS="$(uname -s)"

# Where the runner lives once installed: a private per-user location, out of
# Downloads/Documents and not shown in Finder, so it is not sitting somewhere
# the operator would open or move.
if [ "$OS" = "Darwin" ]; then
  TARGET_DEFAULT="$HOME/Library/Application Support/Signi"
else
  TARGET_DEFAULT="$HOME/.local/share/signi"
fi

# Older installs used a visible ~/casewise-runner folder and an in.casewise.*
# service; clean those up so two runners do not poll at once.
LEGACY_PLIST="$HOME/Library/LaunchAgents/in.casewise.runner.plist"
LEGACY_UNIT="$HOME/.config/systemd/user/casewise-runner.service"
LEGACY_DIR="$HOME/casewise-runner"

say()  { printf '\n\033[1m==> %s\033[0m\n' "$1"; }
ok()   { printf '   \033[32m✓\033[0m %s\n' "$1"; }
warn() { printf '   \033[33m!\033[0m %s\n' "$1"; }
die()  { printf '\n\033[31m✗ %s\033[0m\n' "$1"; exit 1; }

stop_service() {
  if [ "$OS" = "Darwin" ]; then
    launchctl unload "$PLIST" 2>/dev/null || true
    launchctl unload "$LEGACY_PLIST" 2>/dev/null || true
  elif command -v systemctl >/dev/null 2>&1; then
    systemctl --user stop signi-agent 2>/dev/null || true
    systemctl --user stop casewise-runner 2>/dev/null || true
  fi
  pkill -f "$TARGET_DEFAULT/runner.py" 2>/dev/null || true
  pkill -f "$LEGACY_DIR/runner.py" 2>/dev/null || true
  pkill -f "$HERE/runner.py" 2>/dev/null || true
}

# Remove the older branded install so it does not keep polling alongside this one.
remove_legacy() {
  [ "$OS" = "Darwin" ] && launchctl unload "$LEGACY_PLIST" 2>/dev/null || true
  rm -f "$LEGACY_PLIST" "$LEGACY_UNIT" 2>/dev/null || true
  rm -rf "$LEGACY_DIR" 2>/dev/null || true
}

# ---- subcommands -----------------------------------------------------------
case "${1:-install}" in
  stop)
    stop_service; ok "Stopped."; exit 0 ;;
  uninstall)
    stop_service
    rm -f "$PLIST" "$UNIT" 2>/dev/null || true
    [ "$OS" = "Linux" ] && command -v systemctl >/dev/null 2>&1 && systemctl --user daemon-reload 2>/dev/null || true
    ok "Removed. The folder and your config.env are left in place."; exit 0 ;;
  status)
    RUN_DIR="$HERE"; [ -f "$TARGET_DEFAULT/config.env" ] && RUN_DIR="$TARGET_DEFAULT"
    if [ ! -f "$RUN_DIR/config.env" ]; then die "Not set up yet. Run: bash install.sh"; fi
    set -a; # shellcheck disable=SC1091
    . "$RUN_DIR/config.env"; set +a
    if pgrep -f "$RUN_DIR/runner.py" >/dev/null 2>&1; then ok "Runner process is running."; else warn "Runner process is not running. Start it with: bash install.sh"; fi
    code=$(curl -s -o /dev/null -w "%{http_code}" -X POST -H "Authorization: Bearer ${CASEWISE_RUNNER_TOKEN:-}" -H "Content-Type: application/json" -d '{"worker":"status-check"}' "${CASEWISE_SERVER%/}/api/local-runner/poll" || echo 000)
    case "$code" in
      200) ok "Server reachable and token accepted." ;;
      401) die "Server rejected the token. Check CASEWISE_RUNNER_TOKEN in config.env matches the server." ;;
      000) die "Could not reach $CASEWISE_SERVER. Check the internet connection." ;;
      *)   warn "Server answered HTTP $code." ;;
    esac
    tail -n 5 "$RUN_DIR/runner.log" 2>/dev/null || true
    exit 0 ;;
esac

# ---- install ---------------------------------------------------------------

# 1) Move into the private location and run from there. This keeps it out of
#    Downloads/Documents (where macOS also denies a background service read
#    access), and leaves nothing where the operator unzipped it.
if [ "$HERE" != "$TARGET_DEFAULT" ]; then
  say "Installing to a private location"
  mkdir -p "$TARGET_DEFAULT"
  cp -R "$HERE"/. "$TARGET_DEFAULT"/
  SRC="$HERE"
  HERE="$TARGET_DEFAULT"
  cd "$HERE"
  ok "Installed in $HERE"
  # Remove the unzipped copy so it is not left lying around.
  case "$SRC" in
    "$HOME/Downloads"/*|"$HOME/Desktop"/*|"$HOME/Documents"/*|/tmp/*|/private/tmp/*)
      rm -rf "$SRC" 2>/dev/null && ok "Cleaned up the unzipped copy" || true
      ;;
  esac
fi
cd "$HERE"

# 2) config.env must exist and be filled in.
if [ ! -f config.env ]; then
  cp config.example config.env 2>/dev/null || true
  die "config.env was not filled in. Open $HERE/config.env, paste the token and database/captcha values, then run: bash install.sh"
fi

set -a; # shellcheck disable=SC1091
. "$HERE/config.env"; set +a

MISSING=""
for key in CASEWISE_SERVER CASEWISE_RUNNER_TOKEN DB_HOST DB_NAME DB_USER DB_PASSWORD CAPTCHAAI_KEY; do
  val="${!key:-}"
  case "$val" in ""|PASTE*|paste*|CHANGE*|xxx*) MISSING="$MISSING $key" ;; esac
done
[ -n "$MISSING" ] && die "Fill these in $HERE/config.env, then run again:$MISSING"
ok "config.env looks complete"

# 3) Chrome (the automation drives it; Selenium fetches the driver, not Chrome).
if [ "$OS" = "Darwin" ]; then
  [ -d "/Applications/Google Chrome.app" ] && ok "Google Chrome found" \
    || warn "Google Chrome not found. Install it from https://www.google.com/chrome/ or runs will fail."
else
  if command -v google-chrome >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1 || command -v chromium-browser >/dev/null 2>&1; then
    ok "Chrome/Chromium found"
  else
    warn "Chrome/Chromium not found. Install it or runs will fail."
  fi
fi

# 4) Python 3.11 + dependencies, via uv (fetches its own Python; nothing preinstalled needed).
say "Setting up Python $PY_VERSION and dependencies"
export PATH="$HOME/.local/bin:$PATH"
command -v uv >/dev/null 2>&1 || { curl -LsSf https://astral.sh/uv/install.sh | sh; export PATH="$HOME/.local/bin:$PATH"; }
uv python install "$PY_VERSION"
uv venv --python "$PY_VERSION" .venv >/dev/null
# shellcheck disable=SC1091
. .venv/bin/activate
uv pip install --quiet -r requirements.txt -r requirements-automation.txt
PYBIN="$HERE/.venv/bin/python"
ok "Python ready"

# 5) Check the token before installing the service, so problems surface now.
say "Checking the connection to the server"
code=$(curl -s -o /dev/null -w "%{http_code}" -X POST -H "Authorization: Bearer $CASEWISE_RUNNER_TOKEN" -H "Content-Type: application/json" -d '{"worker":"setup-test"}' "${CASEWISE_SERVER%/}/api/local-runner/poll" || echo 000)
case "$code" in
  200) ok "Server reachable and token accepted" ;;
  401) die "The server rejected the token. Check CASEWISE_RUNNER_TOKEN in config.env matches CASEWISE_LOCAL_RUNNER_TOKEN on the server." ;;
  000) die "Could not reach $CASEWISE_SERVER. Check the internet connection and the address." ;;
  *)   warn "Server answered HTTP $code; continuing anyway." ;;
esac

# 6) Install as an always-on background service.
say "Starting the runner in the background"
stop_service
remove_legacy

if [ "$OS" = "Darwin" ]; then
  mkdir -p "$HOME/Library/LaunchAgents"
  cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string><string>-lc</string>
    <string>set -a; source "$HERE/config.env"; set +a; exec "$PYBIN" "$HERE/runner.py"</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>$HERE/runner.log</string>
  <key>StandardErrorPath</key><string>$HERE/runner.log</string>
</dict>
</plist>
PLISTEOF
  launchctl load "$PLIST"
  ok "Installed as a login service"
elif command -v systemctl >/dev/null 2>&1 && [ -d "$HOME/.config" ]; then
  mkdir -p "$HOME/.config/systemd/user"
  cat > "$UNIT" <<UNITEOF
[Unit]
Description=Signi local automation agent
After=network-online.target

[Service]
EnvironmentFile=$HERE/config.env
ExecStart=$PYBIN $HERE/runner.py
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
UNITEOF
  systemctl --user daemon-reload
  systemctl --user enable --now signi-agent.service
  loginctl enable-linger "$USER" 2>/dev/null || true
  ok "Installed as a systemd user service"
else
  set -a; . "$HERE/config.env"; set +a
  nohup "$PYBIN" runner.py >> runner.log 2>&1 &
  warn "Started in the background (no auto-restart after reboot; re-run install.sh then)."
fi

sleep 3
say "Done"
ok "Runner is set up in $HERE and running."
echo "   Check any time:   bash \"$HERE/install.sh\" status"
echo "   Live log:         tail -f \"$HERE/runner.log\""
echo "   Now press 'Run now' on Utilities > Automations."
