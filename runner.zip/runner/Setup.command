# Signi runner
# Double-click this to set up the Casewise runner. It just runs install.sh
# from this folder and keeps the window open so you can read the result.
cd "$(dirname "$0")" || exit 1
bash install.sh
echo
echo "-----------------------------------------------"
echo "Setup finished. You can close this window."
read -n 1 -s -r -p "Press any key to close..."
