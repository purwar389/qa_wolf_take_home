#!/usr/bin/env python3
"""
Casewise local automation runner.

Runs the "Run on your computer" automations from Utilities > Automations on this
machine, headless and in the background. After it is installed once it needs no
attention: it stays running, checks the Casewise server every few seconds, and
when a run is requested it installs anything missing, downloads the compiled
automation, runs it here, reports the result, and deletes the downloaded file.

This file has no secrets in it. The automation itself is never stored: it is
fetched compiled, run from a temporary file, and removed straight after.

Settings come from the environment (see install.sh / config.example):
    CASEWISE_SERVER          e.g. https://prolawyer.casewise.in
    CASEWISE_RUNNER_TOKEN    the same token set on the server
    plus what the automation needs: DB_HOST, DB_USER, ..., CAPTCHAAI_KEY
"""

import os
import socket
import subprocess
import sys
import tempfile
import threading
import time

# The automation drives a browser; headless unless told otherwise, because this
# runs unattended.
os.environ.setdefault("HEADLESS", "true")

SERVER = os.environ.get("CASEWISE_SERVER", "https://prolawyer.casewise.in").rstrip("/")
TOKEN = os.environ.get("CASEWISE_RUNNER_TOKEN", "")
WORKER = os.environ.get("CASEWISE_WORKER", socket.gethostname())
POLL_SECONDS = int(os.environ.get("CASEWISE_POLL_SECONDS", "10"))
HEARTBEAT_SECONDS = int(os.environ.get("CASEWISE_HEARTBEAT_SECONDS", "30"))
PYTHON = os.environ.get("CASEWISE_PYTHON", sys.executable)

# Set while a run is in progress, so the heartbeat can report this machine as
# busy without stopping it from being counted as online.
BUSY = threading.Event()

# What the automation needs to import. Installed automatically if missing, so a
# fresh machine needs no manual pip step.
AUTOMATION_PACKAGES = {
    "requests": "requests>=2.31.0",
    "selenium": "selenium>=4.20.0",
    "pymysql": "pymysql>=1.1.0",
}

API = f"{SERVER}/api/local-runner"


def log(message: str) -> None:
    print(time.strftime("%Y-%m-%d %H:%M:%S"), message, flush=True)


def ensure_packages() -> None:
    """Install any missing dependency, once, so the first run does not fail."""
    import importlib.util

    missing = [spec for name, spec in AUTOMATION_PACKAGES.items()
               if importlib.util.find_spec(name) is None]

    if not missing:
        return

    log(f"Installing dependencies: {', '.join(missing)}")
    subprocess.run([PYTHON, "-m", "pip", "install", "--quiet", *missing], check=True)
    log("Dependencies installed.")


def heartbeat_loop(session) -> None:
    """Tell the server this computer is up every so often, even mid-run, so a
    single 'Run now' knows to fan out to it."""
    while True:
        try:
            session.post(f"{API}/heartbeat",
                         json={"worker": WORKER, "busy": BUSY.is_set()}, timeout=30)
        except Exception:  # noqa: BLE001 - presence is best-effort
            pass
        time.sleep(HEARTBEAT_SECONDS)


def report(session, run_id: int, status: str, message: str = "") -> None:
    try:
        session.post(f"{API}/{run_id}/status",
                     json={"status": status, "message": message[:5000]}, timeout=30)
    except Exception as exc:  # noqa: BLE001 - reporting must never crash the loop
        log(f"Could not report status for run {run_id}: {exc}")


def download_artifact(session, kind: str) -> str:
    """The compiled automation, saved to a temp file. Caller deletes it."""
    response = session.get(f"{API}/artifact", timeout=120)
    response.raise_for_status()

    content = response.content

    # A .pyc must begin with its magic number; if the server ever prefixes the
    # body with stray whitespace, drop it so Python does not reject the file.
    if kind == "pyc":
        content = content.lstrip(b" \t\r\n")

    suffix = ".pyc" if kind == "pyc" else (".exe" if os.name == "nt" else "")
    handle, path = tempfile.mkstemp(prefix="cw_automation_", suffix=suffix)
    with os.fdopen(handle, "wb") as out:
        out.write(content)

    if kind == "binary":
        os.chmod(path, 0o700)

    return path


def run_artifact(path: str, kind: str, extra_env: dict) -> subprocess.CompletedProcess:
    command = [PYTHON, path] if kind == "pyc" else [path]

    # The automation inherits this environment (database and captcha settings),
    # plus whatever was chosen on the website for this run (date scope, limits).
    env = os.environ.copy()
    for key, value in (extra_env or {}).items():
        env[str(key)] = str(value)

    return subprocess.run(command, capture_output=True, text=True, env=env,
                          timeout=int(os.environ.get("CASEWISE_RUN_TIMEOUT", "14400")))


def handle(session, run: dict) -> None:
    run_id = run["id"]
    kind = run.get("artifact_kind", "pyc")
    log(f"Run {run_id} ({run['job_key']}) picked up. Preparing...")

    path = None
    BUSY.set()
    try:
        ensure_packages()
        path = download_artifact(session, kind)
        report(session, run_id, "running", f"Running on {WORKER}.")
        log(f"Run {run_id} started (headless). Settings: {run.get('env', {})}")

        result = run_artifact(path, kind, run.get("env", {}))
        tail = (result.stdout or "")[-2000:] + (result.stderr or "")[-2000:]

        if result.returncode == 0:
            report(session, run_id, "completed", f"Finished on {WORKER}.\n{tail}".strip())
            log(f"Run {run_id} completed.")
        else:
            report(session, run_id, "failed",
                   f"Exited with code {result.returncode} on {WORKER}.\n{tail}".strip())
            log(f"Run {run_id} failed (exit {result.returncode}).")
    except subprocess.TimeoutExpired:
        report(session, run_id, "failed", f"Timed out on {WORKER}.")
        log(f"Run {run_id} timed out.")
    except Exception as exc:  # noqa: BLE001 - the runner must keep going
        report(session, run_id, "failed", f"{type(exc).__name__}: {exc}")
        log(f"Run {run_id} errored: {exc}")
    finally:
        BUSY.clear()
        if path and os.path.exists(path):
            try:
                os.remove(path)
            except OSError:
                pass


def main() -> int:
    if not TOKEN:
        log("CASEWISE_RUNNER_TOKEN is not set. Stopping.")
        return 1

    # requests is needed by the runner itself; make sure it is there before the
    # loop, installing it if this is a bare machine.
    try:
        import requests  # noqa: F401
    except ImportError:
        subprocess.run([PYTHON, "-m", "pip", "install", "--quiet", AUTOMATION_PACKAGES["requests"]], check=True)

    import requests

    session = requests.Session()
    session.headers.update({"Authorization": f"Bearer {TOKEN}"})

    # Presence runs on its own session/thread so it keeps reporting even while a
    # run is holding the main loop.
    hb_session = requests.Session()
    hb_session.headers.update({"Authorization": f"Bearer {TOKEN}"})
    threading.Thread(target=heartbeat_loop, args=(hb_session,), daemon=True).start()

    log(f"Runner started as '{WORKER}', polling {API} every {POLL_SECONDS}s.")

    while True:
        try:
            response = session.post(f"{API}/poll", json={"worker": WORKER}, timeout=30)
            response.raise_for_status()
            run = response.json().get("run")

            if run:
                handle(session, run)
                continue  # look again at once in case more are queued
        except KeyboardInterrupt:
            log("Stopping.")
            return 0
        except Exception as exc:  # noqa: BLE001 - keep polling through outages
            log(f"Could not reach the server: {exc}")

        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    sys.exit(main())
