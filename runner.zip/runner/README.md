# Signi local runner

Carries out the **Run on your computer** automations from Utilities →
Automations on this machine — headless, in the background, unattended.

It has no secrets in it. Each job is fetched **compiled** from the server, run
from a temporary file, and deleted straight after; the automation source is
never stored here.

## Setup — two steps

Install Google **Chrome** if the machine doesn't have it, then:

1. Fill in `config.env` (the values are given to you): the token, and the
   database + captcha settings.
2. Run:
   ```bash
   bash install.sh
   ```

That's it. The installer does everything else and checks itself as it goes:

- moves the folder out of Documents/Desktop/Downloads if needed (macOS blocks
  background apps from reading those),
- refuses to continue if `config.env` is blank, and tells you which fields,
- installs a pinned **Python 3.11** and all dependencies (nothing preinstalled
  needed),
- tests the server and token before finishing,
- installs a background service that starts now and again at every reboot.

After that, nobody touches this machine again — pressing **Run now** on
Utilities → Automations just works. The runner downloads the job, runs it
headless, reports back on that page, and cleans up.

## Handy commands

```bash
bash install.sh status      # is it running and reachable?
bash install.sh stop        # stop it
bash install.sh uninstall   # remove the background service
tail -f runner.log          # watch what it's doing
```

Change a setting: edit `config.env`, then run `bash install.sh` again.
